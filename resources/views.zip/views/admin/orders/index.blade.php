@extends('admin.layout')

@section('content')
    <h1 class="mb-4">Danh sách đơn hàng</h1>

    <!-- Thêm sản phẩm -->
    {{-- <a href="{{ route('admin.products.create') }}" class="btn btn-primary mb-3">Thêm sản phẩm</a> --}}

    <!-- Bảng sản phẩm -->
    <form method="GET" action="{{ route('admin.orders.index') }}" class="mb-3">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Tìm kiếm đơn hàng..." class="form-control w-25 d-inline-block">
        <button type="submit" class="btn btn-primary">Tìm</button>
    </form>
    <table id="productTable" class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Tên</th>
                <th>Số điện thoại</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Mặt hàng</th>
                <th>Người giới thiệu</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($orders as $order)
                <tr>
                    <td>{{ $order->id }}</td>
                    <td>{{ $order->name }}</td>
                    <td>{{ $order->phone }}</td>
                    <td>{{ number_format($order->total, 0, ',', '.') }} VND</td>
                    @php
                        $statusLabels = [
                            'pending' => ['label' => 'Khởi tạo', 'class' => 'secondary'],
                            'approved' => ['label' => 'Duyệt', 'class' => 'info'],
                            'packed' => ['label' => 'Đóng gói', 'class' => 'primary'],
                            'shipped' => ['label' => 'Xuất kho', 'class' => 'warning'],
                            'completed' => ['label' => 'Hoàn thành', 'class' => 'success'],
                            'cancelled' => ['label' => 'Hủy đơn', 'class' => 'danger'],
                        ];

                        $status = $statusLabels[$order->status] ?? ['label' => 'Không xác định', 'class' => 'dark'];
                    @endphp

                    <td>
                        <span class="badge fs-5 bg-{{ $status['class'] }}">
                            {{ $status['label'] }}
                        </span>
                    </td>

                    <td>
                        @foreach ($order->items as $item)
                            <div>- {{ $item->product->name }} (x{{ $item->quantity }})</div>
                        @endforeach
                    </td>
                    <td>
                        @if ($order->referrer)
                            <span class="badge fs-5 bg-secondary ">
                                [#{{ $order->referrer->id }}] - {{ $order->referrer->full_name }}
                            </span>
                        @else
                            <span class="badge fs-5 bg-danger">Không có</span>
                        @endif
                    </td>
                    <td>
                        <div class="d-flex align-items-center gap-1">
                            <a href="{{ route('admin.orders.show', $order->id) }}" class="btn btn-warning btn-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                            <div class="dropdown">
                                <button class="btn btn-primary btn-sm dropdown-toggle" type="button"
                                    id="dropdownMenuButton{{ $order->id }}" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    <i class="fas fa-ellipsis-h"></i>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton{{ $order->id }}">
                                    <!-- Mở popup cập nhật trạng thái -->
                                    <li>
                                        <a href="#" class="dropdown-item" data-bs-toggle="modal"
                                            data-bs-target="#updateStatusModal" data-id="{{ $order->id }}"
                                            data-status="{{ $order->status }}">
                                            Cập nhật trạng thái
                                        </a>
                                    </li>

                                    <!-- Hủy đơn -->
                                    <li>
                                        <form action="{{ route('admin.orders.updateStatus', $order->id) }}" method="POST">
                                            @csrf
                                            @method('PUT')
                                            <input type="hidden" name="status" value="cancelled">
                                            <button type="submit" class="dropdown-item text-danger"
                                                onclick="return confirm('Bạn chắc chắn muốn hủy đơn hàng này?')">
                                                Hủy đơn
                                            </button>
                                        </form>
                                    </li>

                                </ul>
                            </div>



                            {{-- <form action="{{ route('admin.orders.destroy', $order->id) }}" method="POST" onsubmit="return confirm('Xóa sản phẩm này?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form> --}}
                            <a href="{{ route('admin.orders.invoice', $order->id) }}" target="_blank"
                                class="btn btn-secondary btn-sm">
                                <i class="fas fa-print"></i>
                            </a>

                        </div>
                    </td>
                </tr>
            @endforeach

        </tbody>


    </table>
    {{ $orders->links('pagination::bootstrap-5') }}

    <!-- Modal cập nhật trạng thái -->
    <div class="modal fade" id="updateStatusModal" tabindex="-1" aria-labelledby="updateStatusModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <form id="updateStatusForm" method="POST">
                @csrf
                @method('PUT')
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Cập nhật trạng thái đơn hàng</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Đóng"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="statusSelect" class="form-label">Trạng thái</label>
                            <select class="form-select" id="statusSelect" name="status">
                                <option value="pending">Khởi tạo</option>
                                <option value="approved">Duyệt</option>
                                <option value="packed">Đóng gói</option>
                                <option value="shipped">Xuất kho</option>
                                <option value="completed">Hoàn thành</option>
                                <option value="cancelled">Hủy đơn</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Cập nhật</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                    </div>
                </div>
            </form>
        </div>
    </div>


    <script>
        // console.log('window.Echo' . window.Echo); 
        document.addEventListener('DOMContentLoaded', function() {
            const updateStatusModal = document.getElementById('updateStatusModal');
            updateStatusModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                const orderId = button.getAttribute('data-id');
                const currentStatus = button.getAttribute('data-status');

                // Gán form action
                const form = document.getElementById('updateStatusForm');
                form.action = `/admin/orders/${orderId}/status`;

                // Gán trạng thái hiện tại
                document.getElementById('statusSelect').value = currentStatus;
            });
        });
    </script>
@endsection

@push('scripts')
@endpush
