@extends('layout')

@section('title', 'Lịch sử đơn hàng')

@section('content')
    <div class="container">
        <h3 class="mb-4 mt-3">Lịch sử đơn hàng</h3>

        @if ($orders->isEmpty())
            <p>Bạn chưa có đơn hàng nào.</p>
        @else
            @foreach ($orders as $order)
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <strong>Mã đơn: #{{ $order->id }}</strong>
                        <div>
                            @php
                                $statusLabels = [
                                    'pending' => ['label' => 'Khởi tạo', 'class' => 'secondary'],
                                    'approved' => ['label' => 'Duyệt', 'class' => 'info'],
                                    'packed' => ['label' => 'Đóng gói', 'class' => 'primary'],
                                    'shipped' => ['label' => 'Xuất kho', 'class' => 'warning'],
                                    'completed' => ['label' => 'Hoàn thành', 'class' => 'success'],
                                    'cancelled' => ['label' => 'Hủy đơn', 'class' => 'danger'],
                                ];
                                $status = $statusLabels[$order->status] ?? [
                                    'label' => 'Không xác định',
                                    'class' => 'dark',
                                ];
                            @endphp
                            @if (!in_array($order->status, ['completed', 'cancelled']))
                                <div class="dropdown d-inline ms-2">
                                    <a class="btn btn-sm btn-light dropdown-toggle" href="#" role="button"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fas fa-ellipsis-h"></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <form action="{{ route('orders.cancel', $order->id) }}" method="POST"
                                                onsubmit="return confirm('Bạn có chắc muốn hủy đơn hàng này?');">
                                                @csrf
                                                @method('PATCH')
                                                <button type="submit" class="dropdown-item text-danger">
                                                    <i class="bi bi-x-circle me-1"></i> Hủy đơn
                                                </button>
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            @endif
                            <span class="badge bg-{{ $status['class'] }}  text-uppercase">
                                {{ $status['label'] }}
                            </span>

                        </div>
                    </div>
                    <div class="card-body">
                        <p><strong>Ngày đặt:</strong> {{ $order->created_at->format('d/m/Y H:i') }}</p>
                        <p><strong>Tổng tiền:</strong> {{ number_format($order->total, 0, ',', '.') }} VND</p>

                        <ul class="list-group">
                            @foreach ($order->items as $item)
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <img src="{{ asset('storage/' . $item->thumbnail) }}"
                                            alt="{{ $item->product_name }}" width="50" class="me-2">
                                        {{ $item->product_name }} (x{{ $item->quantity }})
                                    </div>
                                    <span>{{ number_format($item->price * $item->quantity, 0, ',', '.') }} VND</span>
                                </li>
                            @endforeach
                        </ul>

                    </div>
                </div>
            @endforeach
        @endif
    </div>
@endsection
